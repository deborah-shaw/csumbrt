package application;

import java.sql.*;
import java.text.DecimalFormat;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

@Controller
public class ControllerPrescriptionCreate {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/*
	 * Doctor requests blank form for new prescription.
	 */
	@GetMapping("/prescription/new")
	public String getPrescriptionForm(Model model) {
		model.addAttribute("prescription", new PrescriptionView());
		return "prescription_create";
	}

	// process data entered on prescription_create form
	@PostMapping("/prescription")
	public String createPrescription(PrescriptionView p, Model model) {
		try {
			int fillNumber = 1;
			/*
			* valid doctor name and id
			* */
			//TODO
			String selectDoctor = "SELECT COUNT(*) FROM Doctor WHERE ID = ? AND First_Name = ? AND Last_Name = ?";
			Integer doctorCountInteger = jdbcTemplate.queryForObject(selectDoctor, Integer.class, p.getDoctor_id(), p.getDoctorFirstName(), p.getDoctorLastName());
			int doctorCount = (doctorCountInteger != null) ? doctorCountInteger : 0;
			if (doctorCount == 0) {
				model.addAttribute("message", "Invalid doctor name and id.");
				model.addAttribute("prescription", p);
				return "prescription_create";
			}

			/*
			* valid patient name and id
			* */
			//TODO
			String selectPatient = "SELECT COUNT(*) FROM Patient WHERE Patient_ID = ? AND First_Name = ? AND Last_Name = ?";
			Integer patientCountInteger = jdbcTemplate.queryForObject(selectPatient, Integer.class, p.getPatient_id(), p.getPatientFirstName(), p.getPatientLastName());
			int patientCount = (patientCountInteger != null) ? patientCountInteger : 0;
			if (patientCount == 0) {
				model.addAttribute("message", "Invalid patient name and id.");
				model.addAttribute("prescription", p);
				return "prescription_create";
			}

			/*
			* valid drug name
			* */
			//TODO
			String selectDrug = "SELECT COUNT(*) FROM Drug WHERE DrugName = ?";
			Integer drugCountInteger = jdbcTemplate.queryForObject(selectDrug, Integer.class, p.getDrugName());
			int drugCount = (drugCountInteger != null) ? drugCountInteger : 0;
			if (drugCount == 0) {
				model.addAttribute("message", "Invalid drug name.");
				model.addAttribute("prescription", p);
				return "prescription_create";
			}

			LocalDate date = LocalDate.now();
			String dateCreated = date.toString();
			p.setDateCreated(dateCreated);

			/*
			 * insert prescription
			 */
			//TODO
			// Need a join here so that I can get drug name from the drug table
			String insertPrescription =
					"INSERT INTO Prescription (Quantity, NumOfRefills, Drug_ID, Doctor_ID, Patient_ID) VALUES (?, ?, (SELECT Drug_ID FROM Drug WHERE DrugName = ?), ?, ?)";

			KeyHolder keyHolder = new GeneratedKeyHolder();

			jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(insertPrescription, Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, p.getQuantity());
                ps.setInt(2, p.getRefills());
                ps.setString(3, p.getDrugName());
                ps.setInt(4, p.getDoctor_id());
                ps.setInt(5, p.getPatient_id());
                return ps;
            }, keyHolder);

			Number rxid = keyHolder.getKey();
			if (rxid != null) {
				p.setRxid(rxid.intValue());
			} else {
				model.addAttribute("message", "Error creating prescription.");
				model.addAttribute("prescription", p);
				return "prescription_create";
			}

			String selectPrice = "SELECT dc.Price FROM Drug d JOIN DrugCost dc ON d.Drug_ID = dc.Drug_ID WHERE d.DrugName = ?";
			Float price = jdbcTemplate.queryForObject(selectPrice, Float.class, p.getDrugName());

			double cost = price * p.getQuantity();
			DecimalFormat decimalFormat = new DecimalFormat("0.00");
			String formattedCost = decimalFormat.format(cost);

			String insertPrescriptionFill = "INSERT INTO PrescriptionFill (RXID, Fill_Number, Price, FillDate, Pharmacy_ID) VALUES (?, ?, ?, CURDATE(), 2)";
			jdbcTemplate.update(insertPrescriptionFill, p.getRxid(), fillNumber, price);

			p.setCost(formattedCost);

//			String selectFillNumber = "SELECT COUNT(*) FROM PrescriptionFill WHERE RXID = ?";
//			Integer fillCount = jdbcTemplate.queryForObject(selectFillNumber, Integer.class, p.getRxid());
//
//			if (fillCount != null && fillCount > 0) {
//				// Retrieve the maximum fill number from the database
//				String selectMaxFillNumber = "SELECT COALESCE(MAX(Fill_Number), 0) FROM PrescriptionFill WHERE RXID = ?";
//				Integer maxFillNumber = jdbcTemplate.queryForObject(selectMaxFillNumber, Integer.class, p.getRxid());
//				fillNumber = (maxFillNumber != null) ? maxFillNumber + 1 : 1;
//			}

			String selectPrescription =
					"SELECT p.RXID, p.Quantity, p.NumOfRefills, d.DrugName, p.Doctor_ID, p.Patient_ID, pf.FillDate, " +
							"pf.Pharmacy_ID, ph.PharmacyName, ph.PharmacyAddress, ph.PharmacyPhone, " +
							"dc.Price " +
							"FROM Prescription p " +
							"INNER JOIN Drug d ON p.Drug_ID = d.Drug_ID " +
							"LEFT JOIN PrescriptionFill pf ON p.RXID = pf.RXID " +
							"LEFT JOIN Pharmacy ph ON pf.Pharmacy_ID = ph.Pharmacy_ID " +
							"LEFT JOIN DrugCost dc ON d.Drug_ID = dc.Drug_ID AND ph.Pharmacy_ID = dc.Pharmacy_ID " +
							"WHERE p.RXID = ?";

			jdbcTemplate.queryForObject(selectPrescription, (ResultSet rs, int rowNum) -> {
				p.setRxid(rs.getInt("RXID"));
				p.setQuantity(rs.getInt("Quantity"));
				p.setRefills(rs.getInt("NumOfRefills"));
				p.setDrugName(rs.getString("DrugName"));
				p.setDoctor_id(rs.getInt("Doctor_ID"));
				p.setPatient_id(rs.getInt("Patient_ID"));
				p.setDateFilled(String.valueOf(rs.getDate("FillDate")));
				p.setPharmacyID(rs.getInt("Pharmacy_ID"));
				p.setPharmacyName(rs.getString("PharmacyName"));
				p.setPharmacyAddress(rs.getString("PharmacyAddress"));
				p.setPharmacyPhone(rs.getString("PharmacyPhone"));
				p.setCost(formattedCost);
				//p.setCost(String.valueOf(rs.getDouble("Price")));
				return p;
			}, p.getRxid());


			model.addAttribute("message", "Prescription created.");
			model.addAttribute("prescription", p);
			return "prescription_show";
		} catch (Exception e) {
			model.addAttribute("message", "Error creating prescription: " + e.getMessage());
			model.addAttribute("prescription", p);
			return "prescription_create";
		}
	}
	
	private Connection getConnection() throws SQLException {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		return conn;
	}

}
