package application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static java.sql.DriverManager.getConnection;

/*
 * Controller class for patient interactions.
 *   register as a new patient.
 *   update patient profile.
 */
@Controller
public class ControllerPatientUpdate {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/*
	 *  Display patient profile for patient id.
	 */
	@GetMapping("/patient/edit/{id}")
	public String getUpdateForm(@PathVariable int id, Model model) {

		PatientView pv = new PatientView();

		pv.setId(id);
		try (Connection conn = getConnection();) {
			PreparedStatement ps_p = conn.prepareStatement ("SELECT Last_Name, First_Name, Birthdate, Street, City, State, ZipCode, Doctor_ID FROM Patient WHERE Patient_ID=?");
			ps_p.setInt(1, id);

			ResultSet rs_p = ps_p.executeQuery();
			if(rs_p.next()) {
				pv.setLast_name(rs_p.getString(1));
				pv.setFirst_name(rs_p.getString(2));
				pv.setBirthdate(rs_p.getString(3));
				pv.setStreet(rs_p.getString(4));
				pv.setCity(rs_p.getString(5));
				pv.setState(rs_p.getString(6));
				pv.setZipcode(rs_p.getString(7));

				PreparedStatement ps_d = conn.prepareStatement("SELECT ID, Last_Name FROM Doctor WHERE ID=?");
				ps_d.setInt(1, rs_p.getInt(8));
				ResultSet rs_d = ps_d.executeQuery();

				if(rs_d.next()) {
					pv.setPrimaryName(rs_d.getString(2));
				}

				model.addAttribute("patient", pv);
				return "patient_edit";
			} else {
				model.addAttribute("message", "Patient not found.");
				model.addAttribute("patient", pv);
				return "patient_get";
			}
		} catch (SQLException e) {
			model.addAttribute("message", "SQL Error."+e.getMessage());
			model.addAttribute("patient", pv);
			return "patient_get";
		}

}

	/*
	 * Process changes from patient_edit form
	 *  Primary doctor, street, city, state, zip can be changed
	 *  ssn, patient id, name, birthdate, ssn are read only in template.
	 */
	@PostMapping("/patient/edit")
	public String updatePatient(PatientView p, Model model) {

		try (Connection conn = getConnection();) {
			PreparedStatement ps_d = conn.prepareStatement("SELECT Last_Name, ID FROM Doctor WHERE Last_Name=?");	// validate doctor last name
			ps_d.setString(1, p.getPrimaryName());

			ResultSet rs_d = ps_d.executeQuery();
			if (rs_d.next()) {
				PreparedStatement ps_p = conn.prepareStatement("UPDATE Patient SET Street=?, City=?, State=?, ZipCode=?, Doctor_ID=? WHERE Patient_ID=?");
				ps_p.setString(1, p.getStreet());
				ps_p.setString(2, p.getCity());
				ps_p.setString(3, p.getState());
				ps_p.setString(4, p.getZipcode());
				ps_p.setInt(5, rs_d.getInt(2));
				ps_p.setInt(6, p.getId());		//limit to user input of patient id

				int numUpdt = ps_p.executeUpdate();		//number of rows updated

				if (numUpdt == 1) {
					model.addAttribute("message", "Update successful");
					model.addAttribute("patient", p);
					return "patient_show";
				} else {
					model.addAttribute("message", "Error. Update was not successful");
					model.addAttribute("patient", p);
					return "patient_edit";
				}

			} else {
				model.addAttribute("message", "Doctor does not exist.");
				model.addAttribute("patient", p);
				return "patient_edit";
			}

		} catch (SQLException e) {
			model.addAttribute("message", "SQL Error." + e.getMessage());
			model.addAttribute("patient", p);
			return "patient_edit";
		}

	}

	/*
	 * return JDBC Connection using jdbcTemplate in Spring Server
	 */
	private Connection getConnection() throws SQLException {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		return conn;
	}

}
