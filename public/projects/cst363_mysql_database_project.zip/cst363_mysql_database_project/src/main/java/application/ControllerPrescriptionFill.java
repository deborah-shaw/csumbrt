package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

@Controller
public class ControllerPrescriptionFill {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/*
	 * Patient requests form to fill prescription.
	 */
	@GetMapping("/prescription/fill")
	public String getfillForm(Model model) {
		model.addAttribute("prescription", new PrescriptionView());
		return "prescription_fill";
	}

	// process data from prescription_fill form
	@PostMapping("/prescription/fill")
	public String processFillForm(PrescriptionView p, Model model) {
		try {
			/*
			 * valid pharmacy name and address, get pharmacy id and phone
			 */
			// TODO
			String countQuery = "SELECT COUNT(*) FROM Pharmacy WHERE PharmacyName = ? AND PharmacyAddress = ?";
			Integer pharmacyCount = jdbcTemplate.queryForObject(countQuery, Integer.class, p.getPharmacyName(), p.getPharmacyAddress());

			if (pharmacyCount == null || pharmacyCount == 0) {
				// Handle the case where the pharmacy is not found
				model.addAttribute("message", "Pharmacy not found.");
				model.addAttribute("prescription", p);
				return "prescription_fill";
			}

			String selectPharmacy = "SELECT Pharmacy_ID, PharmacyPhone FROM Pharmacy WHERE PharmacyName = ? AND PharmacyAddress = ?";
			Map<String, Object> pharmacyInfo = jdbcTemplate.queryForMap(selectPharmacy, p.getPharmacyName(), p.getPharmacyAddress());
			p.setPharmacyID((Integer) pharmacyInfo.get("Pharmacy_ID"));
			p.setPharmacyPhone((String) pharmacyInfo.get("PharmacyPhone"));

			// TODO find the patient information
			String selectPatient = "SELECT * FROM Patient WHERE Last_Name = ?";
			jdbcTemplate.queryForObject(selectPatient, (ResultSet rs, int rowNum) -> {
				p.setPatient_id(rs.getInt("Patient_ID"));
				p.setPatientLastName(rs.getString("Last_Name"));
				p.setPatientFirstName(rs.getString("First_Name"));
				p.setDoctor_id(rs.getInt("Doctor_ID"));
				return p;
			}, p.getPatientLastName());

			// TODO find the prescription
			// Need a join here so that I can get drug name from the drug table
			String countQuery2 = "SELECT COUNT(*) FROM Prescription WHERE RXID = ?";
			Integer prescriptionCount = jdbcTemplate.queryForObject(countQuery2, Integer.class, p.getRxid());

			if (prescriptionCount == null || prescriptionCount == 0) {
				// If no prescription exists for the given RXID, return error message
				model.addAttribute("message", "Prescription not found.");
				model.addAttribute("prescription", p);
				return "prescription_fill";
			}

			String selectPrescription = "SELECT p.RXID, p.Quantity, p.NumOfRefills, d.DrugName, p.Doctor_ID, p.Patient_ID, pf.FillDate " +
					"FROM Prescription p INNER JOIN Drug d ON p.Drug_ID = d.Drug_ID " +
					"LEFT JOIN PrescriptionFill pf ON p.RXID = pf.RXID " +
					"WHERE p.RXID = ?";
			jdbcTemplate.queryForObject(selectPrescription, (ResultSet rs, int rowNum) -> {
				p.setRxid(rs.getInt("RXID"));
				p.setQuantity(rs.getInt("Quantity"));
				p.setRefills(rs.getInt("NumOfRefills"));
				p.setDrugName(rs.getString("DrugName"));
				p.setDoctor_id(rs.getInt("Doctor_ID"));
				p.setPatient_id(rs.getInt("Patient_ID"));
				p.setDateFilled(String.valueOf(rs.getDate("FillDate")));
				return p;
			}, p.getRxid());

			/*
			 * have we exceeded the number of allowed refills
			 * the first fill is not considered a refill.
			 */
			// TODO
            if (p.getRefills() <= 0) {
				model.addAttribute("message", "No refills remaining.");
				model.addAttribute("prescription", p);
				return "prescription_fill";
			}

			int newRefills = p.getRefills() - 1;
			p.setRefills(newRefills);

			/*
			 * get doctor information
			 */
			// TODO
			String selectDoctor = "SELECT * FROM Doctor WHERE ID = ?";
			jdbcTemplate.queryForObject(selectDoctor, (ResultSet rs, int rowNum) -> {
				p.setDoctor_id(rs.getInt("ID"));
				p.setDoctorLastName(rs.getString("Last_Name"));
				p.setDoctorFirstName(rs.getString("First_Name"));
				return p;
			}, p.getDoctor_id());

			/*
			 * calculate cost of prescription
			 */
			// TODO
			// Need a join here so that I can get drug name from the drug table
			String selectDrugCost = "SELECT Price FROM DrugCost WHERE Drug_ID = (SELECT Drug_ID FROM Drug WHERE DrugName = ?) AND Pharmacy_ID = ?";
			Double pricePerUnit = jdbcTemplate.queryForObject(selectDrugCost, Double.class, p.getDrugName(), p.getPharmacyID());
			if (pricePerUnit == null) {
				model.addAttribute("message", "Drug not available at this pharmacy.");
				model.addAttribute("prescription", p);
				return "prescription_fill";
			}

			double cost = pricePerUnit * p.getQuantity();
			DecimalFormat decimalFormat = new DecimalFormat("0.00");
			String formattedCost = decimalFormat.format(cost);
			p.setCost(formattedCost);

			// TODO save updated prescription
			String updatePrescriptionFill = "UPDATE PrescriptionFill SET FillDate = ? WHERE RXID = ?";
			jdbcTemplate.update(updatePrescriptionFill, LocalDate.now(), p.getRxid());

			// show the updated prescription with the most recent fill information
			model.addAttribute("message", "Prescription filled.");
			model.addAttribute("prescription", p);
			return "prescription_show";
		} catch (Exception e) {
			model.addAttribute("message", "Error: " + e.getMessage());
			model.addAttribute("prescription", p);
			return "prescription_fill";
		}
	}
	
	private Connection getConnection() throws SQLException {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		return conn;
	}

}