package application;

import java.sql.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

/*
 * Controller class for patient interactions.
 *   register as a new patient.
 *   update patient profile.
 */
@Controller
public class ControllerPatientCreate {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	/*
	 * Request blank patient registration form.
	 */
	@GetMapping("/patient/new")
	public String getNewPatientForm(Model model) {
		// return blank form for new patient registration
		model.addAttribute("patient", new PatientView());
		return "patient_register";
	}
	
	/*
	 * Process data from the patient_register form
	 */
	@PostMapping("/patient/new")
	public String createPatient(PatientView p, Model model) {

		try (Connection conn = getConnection();) {
			PreparedStatement ps_d = conn.prepareStatement("SELECT Last_Name, ID FROM Doctor WHERE Last_Name=?");	// validate doctor last name
			ps_d.setString(1, p.getPrimaryName());

			ResultSet rs_d = ps_d.executeQuery();
			if (rs_d.next()) {
				PreparedStatement ps_p = conn.prepareStatement("INSERT INTO Patient (Last_Name, First_Name, Birthdate, SSN, Street, City, State, ZipCode, Doctor_ID) VALUES(?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
				ps_p.setString(1, p.getLast_name());
				ps_p.setString(2, p.getFirst_name());
				ps_p.setString(3, p.getBirthdate());
				ps_p.setString(4, p.getSsn());
				ps_p.setString(5, p.getStreet());
				ps_p.setString(6, p.getCity());
				ps_p.setString(7, p.getState());
				ps_p.setString(8, p.getZipcode());
				ps_p.setInt(9, rs_d.getInt(2));

				ps_p.executeUpdate();
				ResultSet rs_p = ps_p.getGeneratedKeys();
				if (rs_p.next()) p.setId(rs_p.getInt(1));

				// display patient data and the generated patient ID,  and success message
				model.addAttribute("message", "Registration successful.");
				model.addAttribute("patient", p);
				return "patient_show";

			} else {
				model.addAttribute("message", "Doctor does not exist.");
				model.addAttribute("patient", p);
				return "patient_register";
			}

		} catch (SQLException e) {
			model.addAttribute("message", "SQL Error." + e.getMessage());
			model.addAttribute("patient", p);
			return "patient_register";
		}

	}
	
	/*
	 * Request blank form to search for patient by id and name
	 */
	@GetMapping("/patient/edit")
	public String getSearchForm(Model model) {
		model.addAttribute("patient", new PatientView());
		return "patient_get";
	}
	
	/*
	 * Perform search for patient by patient id and name.
	 */
	@PostMapping("/patient/show")
	public String showPatient(PatientView p, Model model) {

		// if found, return "patient_show", else return error message and "patient_get"
		try (Connection conn = getConnection();) {
			PreparedStatement ps_p = conn.prepareStatement("SELECT Last_Name, First_Name, Birthdate, Street, City, State, ZipCode, Doctor_ID FROM Patient WHERE Patient_ID=? AND Last_Name=?");
			ps_p.setInt(1, p.getId());
			ps_p.setString(2, p.getLast_name());

			ResultSet rs_p = ps_p.executeQuery();
			if(rs_p.next()) {
				p.setLast_name(rs_p.getString(1));
				p.setFirst_name(rs_p.getString(2));
				p.setBirthdate(rs_p.getString(3));
				p.setStreet(rs_p.getString(4));
				p.setCity(rs_p.getString(5));
				p.setState(rs_p.getString(6));
				p.setZipcode(rs_p.getString(7));

				PreparedStatement ps_d = conn.prepareStatement("SELECT ID, Last_Name FROM Doctor WHERE ID=?");
				ps_d.setInt(1, rs_p.getInt(8));

				ResultSet rs_d = ps_d.executeQuery();
				if(rs_d.next()) {
					p.setPrimaryName(rs_d.getString(2));
				} else {
					System.out.println("no result");
				}

				model.addAttribute("message", "Patient found.");
				model.addAttribute("patient", p);
				return "patient_show";

			} else {
				model.addAttribute("message", "Patient not found.");
				model.addAttribute("patient", p);
				return "patient_get";
			}

		} catch(SQLException e) {
			System.out.println("SQL error in getPatient " + e.getMessage());
			model.addAttribute("message", "SQL Error."+e.getMessage());
			model.addAttribute("patient", p);
			return "patient_get";
		}
	}
	
	/*
	 * return JDBC Connection using jdbcTemplate in Spring Server
	 */
	private Connection getConnection() throws SQLException {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		return conn;
	}
}
