package application;

import java.text.DecimalFormat;
import java.time.LocalDate;

import application.model.*;
import application.service.SequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

@Controller
public class ControllerPrescriptionFill {

	@Autowired
	PharmacyRepository pharmacyRepository;
	@Autowired
	PatientRepository patientRepository;
	@Autowired
	PrescriptionRepository prescriptionRepository;
	@Autowired
	DoctorRepository doctorRepository;

	@Autowired
	SequenceService sequence;

	/*
	 * Patient requests form to fill prescription.
	 */
	@GetMapping("/prescription/fill")
	public String getfillForm(Model model) {
		model.addAttribute("prescription", new PrescriptionView());
		return "prescription_fill";
	}

	// process data from prescription_fill form
	@PostMapping("/prescription/fill")
	public String processFillForm(PrescriptionView p, Model model) {
		// check if the pharmacy exists, if not return error message
		Pharmacy pharmacyM = pharmacyRepository.findByNameAndAddress(p.getPharmacyName(), p.getPharmacyAddress());
		if (pharmacyM == null) {
			model.addAttribute("message", "Pharmacy not found.");
			model.addAttribute("prescription", p);
			return "prescription_fill";
		}

		// check if the patient exists, if not return error message
		Patient patientM = patientRepository.findByLastName(p.getPatientLastName());
		if (patientM == null) {
			model.addAttribute("message", "Patient not found.");
			model.addAttribute("prescription", p);
			return "prescription_fill";
		}

		// check if the prescription exists, if not return error message
		Prescription prescriptionM = prescriptionRepository.findByRxid(p.getRxid());
		if (prescriptionM == null) {
			model.addAttribute("message", "Prescription not found.");
			model.addAttribute("prescription", p);
			return "prescription_fill";
		}

		// check if the prescription has refills remaining, if not return error message
		if (prescriptionM.getRefills() <= 0) {
			model.addAttribute("message", "No refills remaining.");
			model.addAttribute("prescription", p);
			return "prescription_fill";
		}

		// populate doctor information
		Doctor doctorM = doctorRepository.findById(prescriptionM.getDoctorId());
		p.setDoctorId(doctorM.getId());
		p.setDoctorLastName(doctorM.getLastName());
		p.setDoctorFirstName(doctorM.getFirstName());

		pharmacyM.getDrugCosts().forEach(drugCost -> {
			if (drugCost.getDrugName().equals(prescriptionM.getDrugName())) {
				// calculate cost of prescription
				double cost = drugCost.getCost() * prescriptionM.getQuantity();
				DecimalFormat decimalFormat = new DecimalFormat("0.00");
				String formattedCost = decimalFormat.format(cost);
				p.setCost(formattedCost);
			}
		});

		// populate pharmacy information
		p.setPharmacyID(pharmacyM.getId());
		p.setPharmacyName(pharmacyM.getName());
		p.setPharmacyAddress(pharmacyM.getAddress());
		p.setPharmacyPhone(pharmacyM.getPhone());

		// populate prescription information
		p.setPatientId(patientM.getId());
		p.setPatientLastName(patientM.getLastName());
		p.setPatientFirstName(patientM.getFirstName());

		// populate prescription information
		p.setDateFilled(String.valueOf(LocalDate.now()));
		p.setDrugName(prescriptionM.getDrugName());
		p.setQuantity(prescriptionM.getQuantity());
		p.setRefills(prescriptionM.getRefills());

		// populate remaining refills
		int newRefills = prescriptionM.getRefills() - 1;
		prescriptionM.setRefills(newRefills);
		p.setRefills(newRefills);

		// populate prescription fill information
		Prescription.FillRequest fill = new Prescription.FillRequest();
		fill.setPharmacyID(pharmacyM.getId());
		fill.setDateFilled(String.valueOf(LocalDate.now()));
		fill.setCost(p.getCost());
		prescriptionM.getFills().add(fill);

		pharmacyRepository.save(pharmacyM);
		patientRepository.save(patientM);
		prescriptionRepository.save(prescriptionM);
		doctorRepository.save(doctorM);
		model.addAttribute("message", "Prescription filled.");
		model.addAttribute("prescription", p);
		return "prescription_show";
	}
}
