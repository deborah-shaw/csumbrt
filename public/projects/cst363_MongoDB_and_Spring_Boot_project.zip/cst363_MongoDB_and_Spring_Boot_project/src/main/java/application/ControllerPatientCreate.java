package application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import view.PatientView;

import application.model.*;
import application.service.*;
import view.*;

/*
 * Controller class for patient interactions.
 *   register as a new patient.
 *   update patient profile.
 */
@Controller
public class ControllerPatientCreate {
	
	@Autowired
	PatientRepository patientRepository;

	@Autowired
	DoctorRepository doctorRepository;

	@Autowired
	SequenceService sequence;
	
	/*
	 * Request blank patient registration form.
	 */
	@GetMapping("/patient/new")
	public String getNewPatientForm(Model model) {
		// return blank form for new patient registration
		model.addAttribute("patient", new PatientView());
		return "patient_register";
	}
	
	/*
	 * Process data from the patient_register form
	 */
	@PostMapping("/patient/new")
	public String createPatient(PatientView p, Model model) {

		Patient patRepo = patientRepository.findBySsn(p.getSsn());		//check if ssn already exists
		if(patRepo != null) {
			model.addAttribute("message", "SSN already exists.");
			model.addAttribute("patient", p);
			return "patient_register";
		}

		Doctor docRepo = doctorRepository.findByLastName(p.getPrimaryName());		//check if the doctor exists
		if(docRepo != null) {
			int id = sequence.getNextSequence("PATIENT_SEQUENCE");	//get the next unique id
			Patient patientM = new Patient();	//create a model patient instance
			patientM.setId(id);					//copy data from PatientView p to model
			patientM.setSsn(p.getSsn());
			patientM.setFirstName(p.getFirstName());
			patientM.setLastName(p.getLastName());
			patientM.setBirthdate(p.getBirthdate());
			patientM.setStreet(p.getStreet());
			patientM.setCity(p.getCity());
			patientM.setState(p.getState());
			patientM.setZipcode(p.getZipcode());
			patientM.setPrimaryName(p.getPrimaryName());

			p.setId(id);
			patientRepository.insert(patientM);		//insert into repository

			// display patient data and the generated patient ID, and success message
			model.addAttribute("message", "Registration successful.");
			model.addAttribute("patient", p);
			return "patient_show";

		} else {
			model.addAttribute("message", "Doctor does not exist.");
			model.addAttribute("patient", p);
			return "patient_register";
		}

	}
	
	/*
	 * Request blank form to search for patient by id and name
	 */
	@GetMapping("/patient/edit")
	public String getSearchForm(Model model) {
		model.addAttribute("patient", new PatientView());
		return "patient_get";
	}
	
	/*
	 * Perform search for patient by patient id and name.
	 */
	@PostMapping("/patient/show")
	public String showPatient(PatientView p, Model model) {

		// retrieve patient using the id, lastName entered by user
		Patient patRepo = patientRepository.findByIdAndLastName(p.getId(), p.getLastName());
		if(patRepo != null) {	//check if the patient exists
			p.setFirstName(patRepo.getFirstName());
			p.setLastName(patRepo.getLastName());
			p.setBirthdate(patRepo.getBirthdate());
			p.setStreet(patRepo.getStreet());
			p.setCity(patRepo.getCity());
			p.setState(patRepo.getState());
			p.setZipcode(patRepo.getZipcode());
			p.setPrimaryName(patRepo.getPrimaryName());

			model.addAttribute("message", "Patient found.");
			model.addAttribute("patient", p);
			return "patient_show";

		} else {
			model.addAttribute("message", "Patient not found.");
			model.addAttribute("patient", p);
			return "patient_get";
		}
	}

}
