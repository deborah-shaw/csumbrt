package application;

import application.model.DoctorRepository;
import application.model.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import view.PatientView;

import application.model.*;
import application.service.*;
import view.*;

/*
 * Controller class for patient interactions.
 *   register as a new patient.
 *   update patient profile.
 */
@Controller
public class ControllerPatientUpdate {

	@Autowired
	PatientRepository patientRepository;

	@Autowired
	DoctorRepository doctorRepository;
	
	/*
	 *  Display patient profile for patient id.
	 */
	@GetMapping("/patient/edit/{id}")
	public String getUpdateForm(@PathVariable int id, Model model) {

		Patient patRepo = patientRepository.findById(id);		//retrieve patient by id
		if(patRepo != null) {
			PatientView p = new PatientView();
			p.setId(id);
			p.setFirstName(patRepo.getFirstName());
			p.setLastName(patRepo.getLastName());
			p.setBirthdate(patRepo.getBirthdate());
			p.setStreet(patRepo.getStreet());
			p.setCity(patRepo.getCity());
			p.setState(patRepo.getState());
			p.setZipcode(patRepo.getZipcode());
			p.setPrimaryName(patRepo.getPrimaryName());
			model.addAttribute("patient", p);
			return "patient_edit";
		} else {
			model.addAttribute("message", "Patent not found.");
			return "patient_get";
		}
}

	/*
	 * Process changes from patient_edit form
	 *  Primary doctor, street, city, state, zip can be changed
	 *  ssn, patient id, name, birthdate, ssn are read only in template.
	 */
	@PostMapping("/patient/edit")
	public String updatePatient(PatientView p, Model model) {

		Doctor docRepo = doctorRepository.findByLastName(p.getPrimaryName());
		if (docRepo != null) {
			Patient patRepo = patientRepository.findById(p.getId());
			patRepo.setStreet(p.getStreet());
			patRepo.setCity(p.getCity());
			patRepo.setState(p.getState());
			patRepo.setZipcode(p.getZipcode());
			patRepo.setPrimaryName(p.getPrimaryName());
			patientRepository.save(patRepo);
			model.addAttribute("message", "Update successful");
			model.addAttribute("patient", p);
			return "patient_show";

		} else {
			model.addAttribute("message", "Doctor does not exist.");
			model.addAttribute("patient", p);
			return "patient_edit";
		}

	}

}
