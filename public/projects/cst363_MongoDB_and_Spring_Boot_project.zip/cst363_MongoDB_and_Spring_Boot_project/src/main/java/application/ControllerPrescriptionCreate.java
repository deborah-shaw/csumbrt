package application;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;

import application.model.*;
import application.service.SequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import view.*;

@Controller
public class ControllerPrescriptionCreate {

	@Autowired
	DoctorRepository doctorRepository;
	@Autowired
	PatientRepository patientRepository;
	@Autowired
	DrugRepository drugRepository;
	@Autowired
	PrescriptionRepository prescriptionRepository;
	@Autowired
	PharmacyRepository pharmacyRepository;

	@Autowired
	SequenceService sequence;

	/*
	 * Doctor requests blank form for new prescription.
	 */
	@GetMapping("/prescription/new")
	public String getPrescriptionForm(Model model) {
		model.addAttribute("prescription", new PrescriptionView());
		return "prescription_create";
	}

	// process data entered on prescription_create form
	@PostMapping("/prescription")
	public String createPrescription(PrescriptionView p, Model model) {
		// valid doctor name and id
		Doctor doctorM = doctorRepository.findByIdAndFirstNameAndLastName(p.getDoctorId(), p.getDoctorFirstName(), p.getDoctorLastName());
		if (doctorM == null) {
			model.addAttribute("message", "Invalid doctor name and id.");
			model.addAttribute("prescription", p);
			return "prescription_create";
		}

		// valid patient name and id
		Patient patientM = patientRepository.findByIdAndFirstNameAndLastName(p.getPatientId(), p.getPatientFirstName(), p.getPatientLastName());
		if (patientM == null) {
			model.addAttribute("message", "Invalid patient name and id.");
			model.addAttribute("prescription", p);
			return "prescription_create";
		}

		// valid drug name
		Drug drugM = drugRepository.findByName(p.getDrugName());
		if (drugM == null) {
			model.addAttribute("message", "Invalid drug name.");
			model.addAttribute("prescription", p);
			return "prescription_create";
		}

		// get the next unique id for prescription.
		int rxid = sequence.getNextSequence("PRESCRIPTION_SEQUENCE");
		// create prescription
		Prescription prescription = new Prescription();
		prescription.setRxid(rxid);
		prescription.setDrugName(p.getDrugName());
		prescription.setQuantity(p.getQuantity());
		prescription.setPatientId(p.getPatientId());
		prescription.setDoctorId(p.getDoctorId());
		prescription.setDateCreated(p.getDateCreated());
		prescription.setRefills(p.getRefills());
		ArrayList<Prescription.FillRequest> fills = new ArrayList<>();
		prescription.setFills(fills);
		prescriptionRepository.insert(prescription);
		model.addAttribute("prescription", prescription);

		// set pharmacy data and calculate cost of prescription
		Pharmacy pharmacyM = pharmacyRepository.findByDrugCostsDrugName(p.getDrugName());
		p.setPharmacyID(pharmacyM.getId());
		p.setPharmacyName(pharmacyM.getName());
		p.setPharmacyAddress(pharmacyM.getAddress());
		p.setPharmacyPhone(pharmacyM.getPhone());

		pharmacyM.getDrugCosts().forEach(drugCost -> {
			if (drugCost.getDrugName().equals(prescription.getDrugName())) {
				// calculate cost of prescription
				double cost = drugCost.getCost() * prescription.getQuantity();
				DecimalFormat decimalFormat = new DecimalFormat("0.00");
				String formattedCost = decimalFormat.format(cost);
				p.setCost(formattedCost);
			}
		});

		LocalDate date = LocalDate.now();
		String dateCreated = date.toString();
		p.setDateFilled(dateCreated);

		// display message and prescription information
		doctorRepository.save(doctorM);
		patientRepository.save(patientM);
		prescriptionRepository.save(prescription);
		pharmacyRepository.save(pharmacyM);
		model.addAttribute("message", "Prescription created.");
		p.setRxid(rxid);
		model.addAttribute("prescription", p);
		return "prescription_show";
	}
}
