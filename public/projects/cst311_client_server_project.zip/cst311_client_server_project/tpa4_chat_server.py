#!env python

"""Chat server for CST311 Programming Assignment 4"""
__author__ = "Team 9"
__credits__ = [
  "Nicole Al-Sabah",
  "Deborah Shaw",
  "Aaron Berkness"
]

import socket as s
import time
import threading

#Configure logging
import logging
logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

server_port = 12000
socket_list = []     #list of tuple to store (socket, username)
usernames = []         #list to store usernames
offline_messages = {}   #dictionary to store offline messages

def connection_handler(connection_socket, address):
  try:

    username = connection_socket.recv(1024).decode()        #get username for current connection socket
    usernames.append(username)
    
    socket_list.append((connection_socket, username))       #store current socket and username
    print(f"Connected to {username} at {address}")
  
    for other_username in offline_messages:         #send offline messages once the client comes online
      if other_username != username:
        if len(offline_messages[other_username]) == 1:      #if there is only one offline message
          connection_socket.send(offline_messages[other_username][0].encode())
        else:
          for msg in offline_messages[other_username][0:-1]:    #multiple offline messages
            connection_socket.send((msg + "\n").encode())
          connection_socket.send(offline_messages[other_username][-1].encode())

    while True:             #main chat loop
      message = connection_socket.recv(1024).decode()       #receive decoded message from client
      if not message:                 #break loop if stop receiving from client
        break
    
      if message.lower() == 'bye':      #jump to finally block when client sends 'bye'
        break

      #time.sleep(10)
      message = f"{username}: {message}"        #add client username who sends the message
  
      for other_socket, other_username in socket_list:       #send message to other clients
        if other_socket != connection_socket:
          other_socket.send(message.encode())     #encoding to UTF-8
        
      if username not in offline_messages:          #store messages for offline clients
        offline_messages[username] = []
      offline_messages[username].append(message)

  except ConnectionResetError:
    print(f"{username} has left the chat.")
    connection_socket.close()
    pass
  finally:
    for other_socket, other_username in socket_list:     #alert other clients that this client has left the chat
      if other_socket != connection_socket:
        other_socket.send(f"{username} has left the chat.".encode())    #encoding to UTF-8
    print(f"{username} has left the chat.")         #print user left on server screen
    connection_socket.close()
    socket_list.remove((connection_socket, username))   #remove current socket from socket_list

def main():
  #Create a TCP socket
  #Notice the use of SOCK_STREAM for TCP packets
  server_socket = s.socket(s.AF_INET,s.SOCK_STREAM)
  
  #Assign port number to socket, and bind to chosen port
  server_socket.bind(('',server_port))
  
  #Configure how many requests can be queued on the server at once
  server_socket.listen(1)
  
  # Alert user we are now online
  print("Server is listening on Port " + str(server_port))
  
  #Surround with a try-finally to ensure we clean up the socket after we're done
  try:
    #Enter forever loop to listen for requests
    while True:
      #When a client connects, create a new socket and record their address
      connection_socket, address = server_socket.accept()
  
      #create a new thread to handle the connection with each client
      x = threading.Thread(target=connection_handler, args=(connection_socket, address,))
      x.start()
      
  finally:
    server_socket.close()
    log.info("Server socket closed")

if __name__ == "__main__":
  main()
