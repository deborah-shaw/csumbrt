import java.util.HashMap;
import java.util.Objects;

/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */

public abstract class Monster {

    private static int monsterCount;
    protected String name;
    protected Action action;

    public Monster() {
        this("MonsterFace");
    }

    public Monster(String name) {
        this.name = name;
        addMonster();
    }

    public static void addMonster(HashMap<Integer, Monster> monsters, Monster m) {
        monsters.put(monsters.size(), m);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public abstract boolean performAction (int p);  //abstract method

    private static void addMonster() {
        monsterCount++;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public static int getMonsterCount() {
        return monsterCount;
    }

    public static void setMonsterCount(int monsterCount) {
        Monster.monsterCount = monsterCount;
    }

    /**
     * This method checks the current monster and performs different actions depending on the type of parameter value passed in
     * see the prompt for detail
     */
    public final boolean eat(String food){
        if(this instanceof Dragon){
            if("peasants".equals(food)){
                System.out.println("Burna-licious");
                return true;
            }
            else{
                System.out.println("Dragons don't eat " + food);
                return false;
            }
        } else if(this instanceof CookieMonster){
            if("cookie".equals(food)) {
                System.out.println("OM NOM NOM!");
                return true;
            } else {
                System.out.println("C is for cookie not " + food);
                return false;
            }
        } else {
            System.out.println("I don't know what creature this is");
            return false;
        }
    }

    @Override
    public String toString() {
        return "/" + monsterCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Monster monster = (Monster) o;

        return getName() != null ? getName().equals(monster.getName()) : monster.getName() == null;
    }

    @Override
    public int hashCode() {
        return getName() != null ? getName().hashCode() : 0;
    }
}
