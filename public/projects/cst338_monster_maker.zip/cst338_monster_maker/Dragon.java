/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */

public class Dragon extends Monster{

    private int monsterNumber;

    public Dragon() {
        this("trogdor");
    }

    public Dragon(String name) {
        super(name);
        setAction(new Flap(this));  //Create a Flap object using the current Dragon object, then set action in Monster
        monsterNumber = getMonsterCount();
    }

    @Override
    public String toString() {
        return name + " is Dragon " + super.toString();
    }

    public int getMonsterNumber() {
        return monsterNumber;
    }

    public void setMonsterNumber(int monsterNumber) {
        this.monsterNumber = monsterNumber;
    }

    public boolean performAction(int flaps){        //check the value of flaps in Flap to return T/F
        return action.perform(flaps);
    }
}
