/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */
public interface Action {       //interface with only one method
    public boolean perform(int p);
}
