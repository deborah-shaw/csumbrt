/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */

public class CookieMonster extends Monster{

    private int monsterNumber;

    public CookieMonster() {
        this("Blue");
    }

    public CookieMonster(String name) {
        super(name);
        setAction(new Sing(this));  //Create a Sing object using the current CookieMonster object, then set action in Monster
        monsterNumber = getMonsterCount();
    }

    @Override
    public String toString() {
        return name + " is CookieMonster " + super.toString();
    }

    public int getMonsterNumber() {
        return monsterNumber;
    }

    public void setMonsterNumber(int monsterNumber) {
        this.monsterNumber = monsterNumber;
    }

    public boolean performAction(int mins){     //check the value of mins in Sing to return T/F
        return action.perform(mins);
    }
}
