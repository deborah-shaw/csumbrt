/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */

public class Sing implements Action{

    public Monster singer;

    public Sing(Monster m) {
        singer = m;
    }

    public boolean perform(int mins){           //read the prompt for how this method behave
        if(!(singer instanceof CookieMonster)){
            System.out.println(singer.getClass() + " isn't the type of Monster that sings (how sad).");
            return false;
        } else {
            if(mins % 2 == 1 && mins < 15) {
                System.out.println(singer.getName() + " sings C IS FOR COOKIE!! for " + mins + " minutes");
                return true;
            } else {
                System.out.println(singer.getName() + " says it is not time for singing. Maybe in " + mins + " minutes");
                return false;
            }
        }

    }
}
