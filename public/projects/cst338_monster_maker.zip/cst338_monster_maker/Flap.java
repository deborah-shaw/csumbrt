/**
 *
 *<br>
 * This object is Monster Maker.
 * <br>
 * Classes and Interface
 * <br>
 *  @author Deborah Shaw
 *  November 10, 2023
 */

public class Flap implements Action {

    public Monster flapper;

    public Flap(Monster m){
        flapper = m;
    }

    public boolean perform(int flaps){          //read the prompt for how this method behave
        if(!(flapper instanceof  Dragon)) {
            System.out.println(flapper.getClass() + " isn't the type of monster that flaps");
            return false;
        } else {
            if(flaps % 2 == 0 || flaps < 20) {
                System.out.println(flapper.getName() + " flaps it's tiny wings " + flaps + " times");
                return true;
            } else{
                System.out.println(flapper.getName() + " can't even.");
                return false;
            }
        }
    }
}
