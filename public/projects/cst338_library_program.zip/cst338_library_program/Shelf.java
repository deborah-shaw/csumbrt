import Utilities.Code;
import java.util.HashMap;

/**
 *  This is the third class in Project 1. It represents a shelf.
 *  @author Deborah Shaw
 *  November 5, 2023
 */
public class Shelf {
    public static final int SHELF_NUMBER_ = 0;
    public static final int SUBJECT_ = 1;

    private int shelfNumber;
    private String subject;
    private HashMap<Book, Integer> books;

    public Shelf() {
        this.books = new HashMap<>();
    }

    public Shelf(int shelfNumber, String subject) {
        this.shelfNumber = shelfNumber;
        this.subject = subject;
        this.books = new HashMap<>();
    }

    public int getShelfNumber() {
        return shelfNumber;
    }

    public void setShelfNumber(int shelfNumber) {
        this.shelfNumber = shelfNumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public HashMap<Book, Integer> getBooks() {
        return books;
    }

    public void setBooks(HashMap<Book, Integer> books) {
        this.books = books;
    }

    public int getBookCount(Book book) {
        return books.getOrDefault(book, -1);
    }       //https://www.geeksforgeeks.org/hashmap-getordefaultkey-defaultvalue-method-in-java-with-examples/

    public Code addBook(Book book) {
        if (book.getSubject().equals(subject)) {            //if the book exists on the shelf
            books.put(book, books.getOrDefault(book, 0) + 1);   //https://www.geeksforgeeks.org/hashmap-getordefaultkey-defaultvalue-method-in-java-with-examples/
            System.out.println(book.toString() + " added to shelf " + this.toString());
            return Code.SUCCESS;
        } else {                                            //if the book does not exist on the shelf
            return Code.SHELF_SUBJECT_MISMATCH_ERROR;
        }
    }

    public Code removeBook(Book book) {
        if (books.containsKey(book)) {                  //if the book is present in the hashMap and has stock
            if (books.get(book) > 0) {
                books.put(book, books.get(book) - 1);
                System.out.println(book.getTitle() + " successfully removed from " + this.toString());
                return Code.SUCCESS;
            } else {                                    //if the book is present in the hashMap but has no stock
                System.out.println("No copies of " + book.getTitle() + " remain on " + this.toString());
                return Code.BOOK_NOT_IN_INVENTORY_ERROR;
            }
        } else {                                        //if the book is not present in the hashMap
            System.out.println(book.getTitle() + " is not on " + this.toString());
            return Code.BOOK_NOT_IN_INVENTORY_ERROR;
        }
    }

    public String listBooks() {
        StringBuilder sb = new StringBuilder();
        sb.append(books.size()).append(" book on shelf: ").append(this.toString()).append("\n");
        for (Book book : books.keySet()) {
            sb.append(book.toString()).append(" ").append(books.get(book)).append("\n");
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Shelf shelf = (Shelf) o;

        if (shelfNumber != shelf.shelfNumber) return false;
        return subject != null ? subject.equals(shelf.subject) : shelf.subject == null;
    }

    @Override
    public int hashCode() {
        int result = shelfNumber;
        result = 31 * result + (subject != null ? subject.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return shelfNumber + " : " + subject;
    }
}