import Utilities.Code;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LibraryTest {

    Library csumb = null;

    String library00 = "Library00.csv";
    String library01 = "Library01.csv";
    String badBooks0 = "badBooks0.csv";
    String badBooks1 = "badBooks1.csv";
    String badShelves0 = "badShelves0.csv";
    String badShelves1 = "badShelves1.csv";
    String badReader0 = "badReader0.csv";
    String badReader1 = "badReader1.csv";

    @BeforeEach
    void setUp() {
        csumb = new Library("CSUMB");
    }

    @AfterEach
    void tearDown() {
        csumb = null;
    }

    @Test
    void init_test() {
        //Bad file
        assertEquals(Code.FILE_NOT_FOUND_ERROR, csumb.init("nope.csv"));
        assertEquals(Code.BOOK_COUNT_ERROR, csumb.init(badBooks0));
        assertEquals(Code.BOOK_COUNT_ERROR, csumb.init(badBooks1) );
        assertEquals( Code.SHELF_COUNT_ERROR,csumb.init(badShelves0));
        assertEquals( Code.SHELF_NUMBER_PARSE_ERROR,csumb.init(badShelves1));
    }

    @Test
    void init_goodFile_test() {
        // Test a valid file initialization
        String validFile = "Library00.csv"; // Replace with the actual valid file name

        // Assuming the valid file has proper data format and content for initialization
        assertEquals(Code.SUCCESS, csumb.init(validFile));
    }

    @Test
    void addBook() {
        Book book1 = new Book("ISBN123", "Book Title 1", "Science Fiction", 250, "Author 1", LocalDate.now());
        Book book2 = new Book("ISBN456", "Book Title 2", "Fantasy", 300, "Author 2", LocalDate.now());

        // Add a book and check if it's added successfully
        assertEquals(Code.SUCCESS, csumb.addBook(book1));

        // Check if the book is added to the shelves and reflected correctly
        assertNotNull(csumb.getBookByISBN("ISBN123"));

        // Add another book and check if it's added successfully
        assertEquals(Code.SUCCESS, csumb.addBook(book2));

        // Check if the second book is added to the shelves and reflected correctly
        assertNotNull(csumb.getBookByISBN("ISBN456"));

        // Attempt to add a book with an existing ISBN and check the count
        assertEquals(Code.SUCCESS, csumb.addBook(book1));
    }

    @Test
    void returnBook() {
        // Create a book and add it to the library
        Book book1 = new Book("ISBN123", "Book Title 1", "Science Fiction", 250, "Author 1", LocalDate.now());
        csumb.addBook(book1);

        // Create a reader and check out the book
        Reader reader = new Reader(1, "John Doe", "123-456-7890");
        csumb.addReader(reader);
        csumb.checkOutBook(reader, book1);

        // Check if the book is added back to the shelves after return
        assertNotNull(csumb.getBookByISBN("ISBN123"));

        // Attempt to return a book that doesn't belong to any shelf
        Book book2 = new Book("ISBN456", "Book Title 2", "Fantasy", 300, "Author 2", LocalDate.now());
        assertEquals(Code.SHELF_EXISTS_ERROR, csumb.returnBook(book2));
    }

    @Test
    void testReturnBook() {
        // Create a book and add it to the library
        Book book = new Book("ISBN123", "Book Title", "Science Fiction", 250, "Author", LocalDate.now());
        csumb.addBook(book);

        // Create a reader and check out the book
        Reader reader = new Reader(1, "John Doe", "123-456-7890");
        csumb.addReader(reader);
        csumb.checkOutBook(reader, book);

        // Verify that the book is checked out
        assertTrue(reader.getBooks().contains(book));

        // Verify that the book is available in the library after return
        assertNotNull(csumb.getBookByISBN("ISBN123"));
    }

    @Test
    void listBooks() {
        // Create some books and add them to the library
        Book book1 = new Book("ISBN123", "Book Title 1", "Science Fiction", 250, "Author 1", LocalDate.now());
        Book book2 = new Book("ISBN456", "Book Title 2", "Fantasy", 300, "Author 2", LocalDate.now());
        Book book3 = new Book("ISBN789", "Book Title 3", "Mystery", 200, "Author 3", LocalDate.now());

        csumb.addBook(book1);
        csumb.addBook(book2);
        csumb.addBook(book3);

        // Check the number of books in the library
        int totalBooks = csumb.listBooks();

        // Calculate the expected number of books (should match the number of books added)
        int expectedTotalBooks = 1 + 1 + 1; // Assuming each book was added only once

        // Verify that the counted number of books matches the expected total
        assertEquals(expectedTotalBooks, totalBooks);
    }

    @Test
    void checkOutBook() {
        // Create a reader
        Reader reader = new Reader(101, "John Doe", "1234567890");
        csumb.addReader(reader);

        // Create a book and add it to the library
        Book book = new Book("ISBN123", "Book Title", "Science Fiction", 250, "Author", LocalDate.now());
        csumb.addBook(book);

        // Checkout the book for the reader
        Code result = csumb.checkOutBook(reader, book);

        // Verify that the book was successfully checked out
        assertEquals(Code.SUCCESS, result);
    }

    @Test
    void getBookByISBN() {
        // Create a book and add it to the library
        Book book = new Book("ISBN123", "Book Title", "Science Fiction", 250, "Author", LocalDate.now());
        csumb.addBook(book);

        // Retrieve the book using its ISBN
        Book retrievedBook = csumb.getBookByISBN("ISBN123");

        // Verify that the retrieved book matches the added book
        assertNotNull(retrievedBook);
        assertEquals("ISBN123", retrievedBook.getISBN());
        assertEquals("Book Title", retrievedBook.getTitle());
        assertEquals("Science Fiction", retrievedBook.getSubject());
    }

    @Test
    void listShelves() {
        // Add some shelves to the library
        csumb.addShelf("Fantasy");
        csumb.addShelf("Science Fiction");
        csumb.addShelf("Mystery");

        // Retrieve the count of shelves without displaying books
        int shelfCountWithoutBooks = csumb.listShelves(false);

        // Verify that shelves are listed without displaying books
        assertEquals(3, shelfCountWithoutBooks);

        // Retrieve the count of shelves while displaying books
        int shelfCountWithBooks = csumb.listShelves(true);

        // Verify that shelves are listed while displaying books
        assertEquals(3, shelfCountWithBooks);
    }

    @Test
    void addShelf() {
        // Add a shelf to the library
        Shelf shelf = new Shelf(1, "Fantasy");
        Code result = csumb.addShelf(shelf);

        // Verify that the shelf addition is successful
        assertEquals(Code.SUCCESS, result);

        // Add a duplicate shelf
        Shelf duplicateShelf = new Shelf(2, "Fantasy");
        Code duplicateResult = csumb.addShelf(duplicateShelf);

        // Verify that adding a duplicate shelf fails
        assertEquals(Code.SHELF_EXISTS_ERROR, duplicateResult);

        // Add a different shelf
        Shelf anotherShelf = new Shelf(3, "Science Fiction");
        Code anotherResult = csumb.addShelf(anotherShelf);

        // Verify that adding another shelf with a different subject succeeds
        assertEquals(Code.SUCCESS, anotherResult);
    }

    @Test
    void testAddShelf() {
        Library library = new Library("Example Library");

        // Add shelves
        Code resultCode1 = library.addShelf("Science");
        Code resultCode2 = library.addShelf("History");
        Code resultCode3 = library.addShelf("Fiction");

        // Check if shelves were added successfully
        assertEquals(Code.SUCCESS, resultCode1); // Shelf with subject 'Science' added successfully
        assertEquals(Code.SUCCESS, resultCode2); // Shelf with subject 'History' added successfully
        assertEquals(Code.SUCCESS, resultCode3); // Shelf with subject 'Fiction' added successfully

        // Adding a shelf with the same subject again should return an error
        Code resultCode4 = library.addShelf("Science");
        assertEquals(Code.SHELF_EXISTS_ERROR, resultCode4); // Shelf with subject 'Science' already exists
    }

    @Test
    void getShelf() {
        // Add some shelves to the library
        Shelf shelf1 = new Shelf(1, "Fiction");
        Shelf shelf2 = new Shelf(2, "Mystery");
        csumb.addShelf(shelf1);
        csumb.addShelf(shelf2);

        // Retrieve the shelf using the getShelf method for an existing subject
        Shelf foundShelf = csumb.getShelf("Fiction");

        // Check that the shelf is retrieved correctly
        assertNotNull(foundShelf);
        assertEquals("Fiction", foundShelf.getSubject());

        // Retrieve a shelf for a non-existing subject
        Shelf nonExistingShelf = csumb.getShelf("Fantasy");

        // Check that it returns null for a non-existing shelf
        assertNull(nonExistingShelf);
    }

    @Test
    void testGetShelf() {
        Library library = new Library("Example Library");

        // Assuming shelves are added to the library
        Shelf shelf1 = new Shelf(1, "Science");
        Shelf shelf2 = new Shelf(2, "History");
        Shelf shelf3 = new Shelf(3, "Fiction");

        library.addShelf(shelf1);
        library.addShelf(shelf2);
        library.addShelf(shelf3);

        // Test for existing shelf numbers
        assertEquals(shelf1, library.getShelf(1)); // Shelf with number 1 should exist
        assertEquals(shelf2, library.getShelf(2)); // Shelf with number 2 should exist
        assertEquals(shelf3, library.getShelf(3)); // Shelf with number 3 should exist

        // Test for non-existing shelf numbers
        assertNull(library.getShelf(4)); // Shelf with number 4 should not exist
        assertNull(library.getShelf(0)); // Shelf with number 0 should not exist
    }

    @Test
    void listReaders() {
        // Add readers to the library
        Reader reader1 = new Reader(1, "Alice", "123456789");
        Reader reader2 = new Reader(2, "Bob", "987654321");
        csumb.addReader(reader1);
        csumb.addReader(reader2);

        // List readers without showing books
        int readerCountWithoutBooks = csumb.listReaders(false);

        // Check that the count matches the number of added readers
        assertEquals(2, readerCountWithoutBooks);

        // List readers and show their books
        int readerCountWithBooks = csumb.listReaders(true);

        // Check that the count matches the number of added readers
        assertEquals(2, readerCountWithBooks);
    }

    @Test
    void testListReaders() {
        // Add readers to the library
        Reader reader1 = new Reader(1, "Alice", "123456789");
        Reader reader2 = new Reader(2, "Bob", "987654321");
        csumb.addReader(reader1);
        csumb.addReader(reader2);

        // List readers without showing books
        int readerCountWithoutBooks = csumb.listReaders(false);

        // Check that the count matches the number of added readers
        assertEquals(2, readerCountWithoutBooks);

        // List readers and show their books
        int readerCountWithBooks = csumb.listReaders(true);

        // Check that the count matches the number of added readers
        assertEquals(2, readerCountWithBooks);
    }

    @Test
    void getReaderByCard() {
        // Add readers to the library
        Reader reader1 = new Reader(1, "Alice", "123456789");
        Reader reader2 = new Reader(2, "Bob", "987654321");
        csumb.addReader(reader1);
        csumb.addReader(reader2);

        // Retrieve a reader by card number
        Reader foundReader = csumb.getReaderByCard(1);

        // Check if the retrieved reader matches the expected one
        assertNotNull(foundReader);
        assertEquals("Alice", foundReader.getName());
        assertEquals("123456789", foundReader.getPhone());

        // Retrieve a non-existing reader by card number
        Reader nonExistingReader = csumb.getReaderByCard(3);

        // Check that the non-existing reader is null
        assertNull(nonExistingReader);
    }

    @Test
    void addReader() {
        // Create a new reader
        Reader reader = new Reader(1, "Alice", "123456789");

        // Add the reader to the library
        Code resultCode = csumb.addReader(reader);

        // Check if the reader is added successfully
        assertEquals(Code.SUCCESS, resultCode);

        // Try adding the same reader again
        Code duplicateResultCode = csumb.addReader(reader);

        // Check if the duplicate addition is caught
        assertEquals(Code.READER_ALREADY_EXISTS_ERROR, duplicateResultCode);
    }

    @Test
    void removeReader() {
        // Create a new reader
        Reader reader = new Reader(1, "Alice", "123456789");

        // Add the reader to the library
        csumb.addReader(reader);

        // Try removing the reader
        Code removeResultCode = csumb.removeReader(reader);

        // Check if the reader is removed successfully
        assertEquals(Code.SUCCESS, removeResultCode);

        // Try removing the same reader again
        Code duplicateRemoveResultCode = csumb.removeReader(reader);

        // Check if trying to remove the reader again returns an error code
        assertEquals(Code.READER_NOT_IN_LIBRARY_ERROR, duplicateRemoveResultCode);
    }

    @Test
    void convertInt() {
        String validRecordCount = "10";
        String invalidRecordCount = "invalid";

        Code codeForValid = Code.BOOK_COUNT_ERROR;
        Code codeForInvalid = Code.PAGE_COUNT_ERROR;

        // Test valid conversion
        int convertedValid = Library.convertInt(validRecordCount, codeForValid);
        assertEquals(10, convertedValid);

        // Test invalid conversion
        int convertedInvalid = Library.convertInt(invalidRecordCount, codeForInvalid);
        assertEquals(codeForInvalid.getCode(), convertedInvalid);
    }

    @Test
    void convertDate() {
        String validDateString = "2023-11-21";
        String invalidDateString = "invalid-date";

        Code codeForValid = Code.SUCCESS;
        Code codeForInvalid = Code.DATE_CONVERSION_ERROR;

        // Test valid conversion
        LocalDate convertedValid = Library.convertDate(validDateString, codeForValid);
        LocalDate expectedValid = LocalDate.of(2023, 11, 21);
        assertEquals(expectedValid, convertedValid);

        // Test invalid conversion
        LocalDate convertedInvalid = Library.convertDate(invalidDateString, codeForInvalid);
        LocalDate defaultDate = LocalDate.of(1970, 1, 1);
        assertEquals(defaultDate, convertedInvalid);
    }

    @Test
    void getLibraryCardNumber() {
        Library library = new Library("CSUMB");

        // Assuming initial library card number is zero
        assertEquals(1, library.getLibraryCardNumber()); // Expected library card number after the first addition

        // Adding readers and increasing card numbers
        Reader reader1 = new Reader(101, "John Doe", "123-456-7890");
        Reader reader2 = new Reader(102, "Jane Smith", "987-654-3210");
        library.addReader(reader1);
        library.addReader(reader2);

        // Assuming the latest card number becomes 102
        assertEquals(103, library.getLibraryCardNumber()); // Expected library card number after adding two readers
    }
}