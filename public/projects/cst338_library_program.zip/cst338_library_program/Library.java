import Utilities.Code;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLOutput;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.*;

/**
 * This is the forth class in Project 1. It represents a library.
 * @author Deborah Shaw
 * November 15, 2023
 */

public class Library {

    public static final int LENDING_LIMIT = 5;
    private static int libraryCard;               //static
    private String name;
    private HashMap<Book, Integer> books;
    private HashMap<String, Shelf> shelves;
    private List<Reader> readers;

    public Library(String name) {
        this.name = name;
        books = new HashMap<>();
        shelves = new HashMap<>();
        readers = new ArrayList<>();
    }

    public Code addBook(Book newBook) {
        Code code = Code.SUCCESS;
        if(books.containsKey(newBook)) {                        //if the book already in books HashMap, increament the count
            books.put(newBook, books.get(newBook) + 1);
            System.out.println(books.get(newBook) +" copies of " + newBook.getTitle() + " in the stacks");
        } else {
            books.put(newBook, 1);                              //if the book does not exist, add the book and set the count to 1
            System.out.println(newBook.getTitle() + " added to the stacks.");
        }
        for(Shelf shelf : shelves.values()) {                   //if there is a shelf with matching subject, add the book to that shelf
            if(shelf.getSubject().equals(newBook.getSubject())) {
                code = shelf.addBook(newBook);
            } else {
                System.out.println("No shelf for " + newBook.getSubject() + " books");
                code = Code.SHELF_EXISTS_ERROR;
            }
        }
        return code;
    }

    private Code addBookToShelf(Book book, Shelf shelf) {       //find the matching shelf with the book, then add the book to the shelf
        Code returnCode = returnBook(book);
        if(returnCode == Code.SUCCESS) {
            return Code.SUCCESS;
        } else if(!shelf.getSubject().equals(book.getSubject())) {
            return Code.SHELF_SUBJECT_MISMATCH_ERROR;
        } else {
            Code addBookResult = shelf.addBook(book);
            if(addBookResult == Code.SUCCESS) {
                System.out.println(book + " added to shelf");
                return Code.SUCCESS;
            } else {
                System.out.println("Could not add " + book + " to shelf");
                return addBookResult;
            }
        }
    }

    public Code addReader(Reader reader) {              //add a reader to the list of readers in the library object
        if(readers.contains(reader)) {
            System.out.println(reader.getName() + " already has an account!");
            return Code.READER_ALREADY_EXISTS_ERROR;
        }
        for(Reader r : readers) {
            if(r.getCardNumber() == reader.getCardNumber()) {
                System.out.println(r.getName() + " and " + reader.getName() + " have the same card number!");
                return Code.READER_CARD_NUMBER_ERROR;
            }
        }
        readers.add(reader);
        System.out.println(reader.getName() + " added to the library!");
        if(reader.getCardNumber() > libraryCard) {
            libraryCard = reader.getCardNumber();
        }
        return Code.SUCCESS;
    }

    public Code addShelf(Shelf shelf) {             //add a shelf by passing an object
        for(Shelf existShelf : shelves.values()) {
            if(existShelf.getSubject().equals(shelf.getSubject())){
                System.out.println("Error: shelf already exists");
                return Code.SHELF_EXISTS_ERROR;
            }
        }
        shelf.setShelfNumber(shelves.size() + 1);
        shelves.put(shelf.getSubject(), shelf);
        return Code.SUCCESS;
    }

    public Code addShelf(String shelfSubject) {                     //add a shelf by passing a matching subject
        Shelf shelf = new Shelf(shelves.size() + 1, shelfSubject);
        return addShelf(shelf);
    }

    public Code checkOutBook(Reader reader, Book book) {
        if(!readers.contains(reader)) {                             //check if the reader exists
            System.out.println(reader.getName() + " doesn't have an account here");
            return Code.READER_NOT_IN_LIBRARY_ERROR;
        }
        if(reader.getBooks().size() >= LENDING_LIMIT) {             //check if the reader reaches lending limit
            System.out.println(reader.getName() + " has reached the lending limit, " + LENDING_LIMIT);
            return Code.BOOK_LIMIT_REACHED_ERROR;
        }
        if(!books.containsKey(book)) {
            System.out.println("ERROR: could not find " + book.getTitle());
        }
        for(Shelf shelf : shelves.values()) {                       //find the matching shelf for the book
            if(!shelf.getBooks().containsKey(book)) {
                System.out.println("no shelf for " + shelf.getSubject() + " books");
                return Code.SHELF_EXISTS_ERROR;
            }
            if(shelf.getBooks().get(book) < 1) {
                System.out.println("ERROR: no copies of " + book.getTitle() + " remain");
                return Code.BOOK_NOT_IN_INVENTORY_ERROR;
            }
        }
        if(!(reader.addBook(book) == Code.SUCCESS)) {               //add the checked out book to the reader's list
            System.out.println("Couldn't checkout " + book.getTitle());
            return reader.addBook(book);
        }
        for(Shelf shelf : shelves.values()) {
            if (shelf.getBooks().containsKey(book)) {
                System.out.println(book.getTitle() + " checked out successfully");
                return shelf.removeBook(book);
            }
        }
        return Code.SUCCESS;    //don't think we need this
    }

    public static LocalDate convertDate(String date, Code errorCode) {      //static method, convert string date to date format
        if(date.equals("0000")) {
            return LocalDate.of(1970, 1,1);
        }
        String[] dateElements = date.split("-");
        if(dateElements.length != 3) {
            System.out.println("ERROR: date conversion error, could not parse " + date);
            System.out.println("Using default date (01-Jan-1970");
            return LocalDate.of(1970, 1,1);
        }
        int year = Integer.parseInt(dateElements[0]);
        int month = Integer.parseInt(dateElements[1]);
        int day = Integer.parseInt(dateElements[2]);

        if(year < 0 || month < 0 || day < 0) {
            System.out.println("Error converting date: Year " + year);
            System.out.println("Error converting date: Month " + month);
            System.out.println("Error converting date: Day " + day);
            System.out.println("Using default date (01-Jan-1970)");
            return LocalDate.of(1970, 1, 1);
        }
        return LocalDate.of(year, month, day);
    }

    public static int convertInt(String recordCountString, Code code) {         //static method, convert string to integer
        try{
            return Integer.parseInt(recordCountString);
        } catch (NumberFormatException e) {
            System.out.println("Value which cause the error: " + recordCountString);
            System.out.println("Error message: " + code.getMessage());

            switch (code) {
                case BOOK_COUNT_ERROR:
                    System.out.println("Error: Could not read number of books");
                    break;
                case PAGE_COUNT_ERROR:
                    System.out.println("Error: Could not parse page count");
                    break;
                case DATE_CONVERSION_ERROR:
                    System.out.println("Error: Could not parse date component");
                    break;
                default:
                    System.out.println("Error: Unknown conversion error");
                    break;
            }
            return code.getCode();
        }
    }

//    private Code errorCode(int codeNumber) {
//        for(Code code : Code.values()) {
//            if (Code.getCode() == codeNumber) {
//                return code;
//            }
//        }
//    return Code.UNKNOWN_ERROR;
//    }

    public Book getBookByISBN(String isbn) {
        for(Book book : books.keySet()) {
            if(book.getISBN().equals(isbn)){
                return book;
            }
        }
        return null;
    }

    public int getLibraryCardNumber() {   //static
        return libraryCard + 1;
    }

    public String getName() {
        return name;
    }

    public Reader getReaderByCard(int cardNumber) {
        for(Reader reader : readers) {
            if(reader.getCardNumber() == cardNumber) {
                return reader;
            }
        }
        System.out.println("Could not find a reader with card #" + cardNumber);
        return null;
    }

    public Shelf getShelf(String subject) {
        for(Shelf shelf : shelves.values()){
            if(shelf.getSubject().equals(subject)) {
                return shelf;
            }
        }
        System.out.println("No shelf for " + subject + " books");
        return null;
    }

    public Shelf getShelf(Integer shelfNumber) {
        for(Shelf shelf : shelves.values()) {
            if(shelf.getShelfNumber() == shelfNumber) {
                return shelf;
            }
        }
        System.out.println("No shelf number " + shelfNumber + " found");
        return null;
    }

    public Code init(String filename) {             //parse contents in a file then initialize book/reader/shelf
        File file = new File(filename);
        Scanner scanner;
        try{
            scanner = new Scanner(file);
        } catch (FileNotFoundException e) {
            return Code.FILE_NOT_FOUND_ERROR;
        }

        int booksCount = convertInt(scanner.nextLine(), Code.BOOK_COUNT_ERROR);
        if(booksCount < 0) {
            return Code.BOOK_COUNT_ERROR;
        }
        Code bookInitCode = initBooks(booksCount, scanner);
        if(bookInitCode != Code.SUCCESS) {
            System.out.println("book count: " + booksCount);
            return Code.BOOK_COUNT_ERROR;
        }
        listBooks();

        int shelvesCount = convertInt(scanner.nextLine(), Code.SHELF_COUNT_ERROR);
        if(shelvesCount < 0) {
            return Code.SHELF_COUNT_ERROR;
        }
        Code shelfInitCode = initShelves(shelvesCount, scanner);
        if(shelfInitCode != Code.SUCCESS) {
            return shelfInitCode;
        }
        listShelves();

        int readersCount = convertInt(scanner.nextLine(), Code.READER_COUNT_ERROR);
        if(readersCount < 0) {
            return Code.READER_COUNT_ERROR;
        }
        Code readerInitCode = initReader(readersCount, scanner);
        if(readerInitCode != Code.SUCCESS) {
            return readerInitCode;
        }
        listReaders();
        return Code.SUCCESS;
    }

    private Code initBooks(int bookCount, Scanner scan) {               //initialize a book
        if(bookCount < 1) {
            return Code.LIBRARY_ERROR;
        }
        for(int i = 0; i < bookCount; i++) {
            String line = scan.nextLine();
            String[] bookDetails = line.split(",");
            if(bookDetails.length < Book.DUE_DATE_) {
                return Code.BOOK_COUNT_ERROR;
            }

            String isbn = bookDetails[Book.ISBN_];
            String title = bookDetails[Book.TITLE_];
            String subject = bookDetails[Book.SUBJECT_];

            int pageCount;
            try{
                pageCount = convertInt(bookDetails[Book.PAGE_COUNT_], Code.PAGE_COUNT_ERROR);
            } catch(NumberFormatException e) {
                return Code.PAGE_COUNT_ERROR;
            }
            if(pageCount <= 0) {
                return Code.PAGE_COUNT_ERROR;
            }

            String author = bookDetails[Book.AUTHOR_];
            String dueDateStr = bookDetails[Book.DUE_DATE_];
            LocalDate dueDate = convertDate(dueDateStr, Code.DATE_CONVERSION_ERROR);

            if(dueDate == null) {
                return Code.DATE_CONVERSION_ERROR;
            }
            Book book = new Book(isbn, title, subject, pageCount, author, dueDate);
            Code addBookResult = addBook(book);

            if(addBookResult != Code.SUCCESS) {
                return addBookResult;
            }
        }
        return Code.SUCCESS;
    }

    private Code initReader(int readerCount, Scanner scan) {            //initialize a reader
        if(readerCount <= 0) {
            return Code.READER_COUNT_ERROR;
        }

        for(int i = 0; i < readerCount && scan.hasNextLine(); i++) {
            String line = scan.nextLine();
            String[] readerDetails = line.split(",");

            if(readerDetails.length < Reader.BOOK_START_) {
                return Code.READER_COUNT_ERROR;
            }

            int cardNumber;
            try{
                cardNumber = Integer.parseInt(readerDetails[Reader.CARD_NUMBER_]);
            } catch (NumberFormatException e) {
                return Code.READER_COUNT_ERROR;
            }
            String name = readerDetails[Reader.NAME_];
            String phone = readerDetails[Reader.PHONE_];

            Reader reader = new Reader(cardNumber, name, phone);

            int bookCount;
            try{
                bookCount = convertInt(readerDetails[Reader.BOOK_COUNT_], Code.READER_COUNT_ERROR);
            } catch(NumberFormatException e) {
                return Code.READER_COUNT_ERROR;
            }

            int bookStartIndex = Reader.BOOK_START_;
            for(int j = 0; j < bookCount; j++) {
                String isbn = readerDetails[bookStartIndex++];
                Book book = getBookByISBN(isbn);

                if(book == null) {
                    System.out.println("ERROR: Book with ISBN " + isbn + " not found");
                    continue;
                }

                LocalDate dueDate = convertDate(readerDetails[bookStartIndex++], Code.DATE_CONVERSION_ERROR);

                if(dueDate == null) {
                    return Code.DATE_CONVERSION_ERROR;
                }

                Code checkOutCode = checkOutBook(reader, book);
                if(checkOutCode != Code.SUCCESS) {
                    System.out.println("ERROR: Unable to check out book with ISBN " + isbn);
                }
            }
            Code addReaderCode = addReader(reader);
        }
        return Code.SUCCESS;
    }

    private Code initShelves(int shelfCount, Scanner scan) {                    //initialize a shelf
        if(shelfCount < 1) {
            return Code.SHELF_COUNT_ERROR;
        }
        int parsedShelfCount = 0;
        while(parsedShelfCount < shelfCount && scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] shelfDetails = line.split(",");

            if(shelfDetails.length < Shelf.SUBJECT_) {
                return Code.SHELF_NUMBER_PARSE_ERROR;
            }
            int shelfNumber;
            try {
                shelfNumber = convertInt(shelfDetails[Shelf.SHELF_NUMBER_], Code.SHELF_NUMBER_PARSE_ERROR);
            } catch (NumberFormatException e) {
                return Code.SHELF_NUMBER_PARSE_ERROR;
            }

            if(shelfNumber < 0) {                   //need to check shelfNumber is not-negative for badShelves1.csv
                return Code.SHELF_NUMBER_PARSE_ERROR;
            }

            String shelfSubject = shelfDetails[Shelf.SUBJECT_];
            Shelf shelf = new Shelf(shelfNumber, shelfSubject);
            Code addShelfCode = addShelf(shelf);
            parsedShelfCount++;
        }
        if(parsedShelfCount != shelfCount) {
            System.out.println("Number of shelves doesn't match expected");
            return Code.SHELF_NUMBER_PARSE_ERROR;
        }
        return Code.SUCCESS;
    }

    public int listBooks() {
        int bookCount = 0;
        for(Book book : books.keySet()) {
            System.out.println(books.get(book) + " copies of " + book.toString());
            bookCount += books.get(book);
        }
        return bookCount;
    }

    public int listReaders() {
        for(Reader reader : readers) {
            System.out.println(reader.toString());
        }
        return readers.size();
    }

    public int listReaders(boolean showBooks) {
        if(showBooks) {
            for(Reader reader : readers) {
                System.out.println(reader.toString());
            }
            return readers.size();
        } else {
            return listReaders();
        }
    }

    public int listShelves(boolean showBooks) {
        if(showBooks) {
            for(Shelf shelf : shelves.values()){
                this.listBooks();
            }
        } else {
            for(Shelf shelf : shelves.values()){
                System.out.println(shelf.toString());
            }
        }
        return shelves.size();
    }

    public int listShelves() {
        return listShelves(false);
    }

    public Code removeReader(Reader reader) {
        if(readers.contains(reader)) {
            if(reader.getBookCount() > 0) {
                System.out.println(reader.getName() + " must return all books!");
                return Code.READER_STILL_HAS_BOOKS_ERROR;
            } else {
                readers.remove(reader);
                return Code.SUCCESS;
            }
        } else {
            System.out.println(reader.getName() + " is not part of this Library");
            return Code.READER_NOT_IN_LIBRARY_ERROR;
        }
    }

    public Code returnBook(Reader reader, Book book) {
        Code code;
        if(!reader.getBooks().contains(book)) {                 //check if the reader has the book
            System.out.println(reader.getName() + " doesn't have " + book.getTitle() + " checked out");
            return Code.READER_DOESNT_HAVE_BOOK_ERROR;
        }
        if(!books.containsKey(book)) {
            return Code.BOOK_NOT_IN_INVENTORY_ERROR;
        }
        System.out.println(reader.getName() + " is returning " + book.getTitle());
        code = reader.removeBook(book);
        if(code == Code.SUCCESS) {
            code = returnBook(book);
            return code;
        } else{
            System.out.println("Could not return " + book.getTitle());
            return code;
        }
    }

    public Code returnBook(Book book) {
        Code code = Code.SHELF_EXISTS_ERROR;
        for(Shelf shelf : shelves.values()) {
            if(!shelf.getSubject().equals(book.getSubject())) {
                System.out.println("No shelf for " + book.toString());
                return code;
            } else {
                code = shelf.addBook(book);
            }
        }
        return code;
    }
}